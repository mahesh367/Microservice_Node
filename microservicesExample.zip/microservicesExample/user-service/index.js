const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const app = express();
const PORT = 3001;

app.use(bodyParser.json());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'microservices_db'
});

db.connect(err => {
    if (err) throw err;
    console.log('Connected to MySQL');
});


app.post('/users', (req, res) => {
    const user = req.body;
    db.query('INSERT INTO users (name) VALUES (?)', [user.name], (err, result) => {
        if (err) throw err;
        res.status(201).send({ id: result.insertId, ...user });
    });
});

app.get('/users', (req, res) => {
    db.query('SELECT * FROM users', (err, results) => {
        if (err) throw err;
        res.send(results);
    });
});

app.get('/users/:id', (req, res) => {
    db.query('SELECT * FROM users WHERE id = ?', [req.params.id], (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            res.send(result[0]);
        } else {
            res.status(404).send({ message: 'User not found' });
        }
    });
});

app.listen(PORT, () => {
    console.log(`User Service is running on port ${PORT}`);
});
