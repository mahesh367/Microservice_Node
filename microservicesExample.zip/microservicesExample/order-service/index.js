const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const mysql = require('mysql2');
const app = express();
const PORT = 3002;

app.use(bodyParser.json());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'microservices_db'
});

db.connect(err => {
    if (err) throw err;
    console.log('Connected to MySQL');
});

app.post('/orders', async (req, res) => {
    const order = req.body;
    try {
        const userResponse = await axios.get(`http://localhost:3001/users/${order.userId}`);
        if (userResponse.status === 200) {
            db.query('INSERT INTO orders (userId, productId) VALUES (?, ?)', [order.userId, order.productId], (err, result) => {
                if (err) throw err;
                res.status(201).send({ id: result.insertId, ...order });
            });
        } else {
            res.status(400).send({ message: 'Invalid user ID' });
        }
    } catch (error) {
        res.status(400).send({ message: 'Invalid user ID' });
    }
});

app.get('/orders', (req, res) => {
    const sql = `
        SELECT 
            orders.id AS orderId,
            users.id AS userId,
            users.name AS userName,
            products.id AS productId,
            products.name AS productName
        FROM orders
        JOIN users ON orders.userId = users.id
        JOIN products ON orders.productId = products.id
    `;
    db.query(sql, (err, results) => {
        if (err) {
            console.error(err);
            res.status(500).send({ message: 'Error retrieving orders' });
        } else {
            res.send(results);
        }
    });
});

app.get('/orders/:id', (req, res) => {
    const sql = `
        SELECT 
            orders.id AS orderId,
            users.id AS userId,
            users.name AS userName,
            products.id AS productId,
            products.name AS productName
        FROM orders
        JOIN users ON orders.userId = users.id
        JOIN products ON orders.productId = products.id
        WHERE orders.id = ?
    `;
    db.query(sql, [req.params.id], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send({ message: 'Error retrieving order' });
        } else if (result.length > 0) {
            res.send(result[0]);
        } else {
            res.status(404).send({ message: 'Order not found' });
        }
    });
});

app.listen(PORT, () => {
    console.log(`Order Service is running on port ${PORT}`);
});
