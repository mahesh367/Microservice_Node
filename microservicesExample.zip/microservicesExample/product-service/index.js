const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const app = express();
const PORT = 3003;

app.use(bodyParser.json());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'microservices_db'
});

db.connect(err => {
    if (err) throw err;
    console.log('Connected to MySQL');
});

app.post('/products', (req, res) => {
    const product = req.body;
    db.query('INSERT INTO products (name) VALUES (?)', [product.name], (err, result) => {
        if (err) throw err;
        res.status(201).send({ id: result.insertId, ...product });
    });
});

app.get('/products', (req, res) => {
    db.query('SELECT * FROM products', (err, results) => {
        if (err) throw err;
        res.send(results);
    });
});

app.get('/products/:id', (req, res) => {
    db.query('SELECT * FROM products WHERE id = ?', [req.params.id], (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            res.send(result[0]);
        } else {
            res.status(404).send({ message: 'Product not found' });
        }
    });
});

app.listen(PORT, () => {
    console.log(`Product Service is running on port ${PORT}`);
});
